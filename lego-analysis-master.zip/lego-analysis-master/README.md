# lego-analysis

Data & Python Notebook that corresponds to my lego analysis YouTube tutorial:
https://youtu.be/BzQDi4D0B_M
